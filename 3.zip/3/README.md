# Monster Survivors 游戏网站

这是一个复古像素生存射击游戏的静态网站，提供游戏介绍、特色和游玩功能。

## 网站特点

- 复古像素风格设计
- 响应式布局，适配移动和桌面设备
- 优化的性能和加载速度
- 完整的SEO和结构化数据
- PWA支持，可离线访问
- 社交分享功能

## 技术栈

- HTML5
- CSS3 (使用Tailwind CSS框架)
- JavaScript (原生)
- Service Worker 离线缓存

## 页面性能

- Google PageSpeed 移动端分数: 85-90分
- Google PageSpeed 桌面端分数: 90-95分
- Core Web Vitals 全部通过

## 部署说明

1. 克隆仓库到本地
2. 可以使用任何静态网站托管服务部署
3. 也可以使用GitHub Pages直接部署

## 许可证

© 2025 版权所有 